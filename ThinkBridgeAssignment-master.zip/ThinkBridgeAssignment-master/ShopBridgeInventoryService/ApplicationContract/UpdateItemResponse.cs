﻿namespace ShopBridge.Inventory.ApplicationContract
{
    public class UpdateItemResponse : InventoryServiceResponse
    {
    }
}
