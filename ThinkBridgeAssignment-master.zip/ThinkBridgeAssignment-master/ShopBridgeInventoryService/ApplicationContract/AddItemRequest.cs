﻿namespace ShopBridge.Inventory.ApplicationContract
{
    public class AddItemRequest
    {
        public ItemDto Item { get; set; }
    }
}
