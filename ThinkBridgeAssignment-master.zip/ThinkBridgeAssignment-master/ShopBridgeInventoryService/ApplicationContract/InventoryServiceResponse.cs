﻿namespace ShopBridge.Inventory.ApplicationContract
{
    public class InventoryServiceResponse
    {
        public string ErrorMessage { get; set; }
    }
}
