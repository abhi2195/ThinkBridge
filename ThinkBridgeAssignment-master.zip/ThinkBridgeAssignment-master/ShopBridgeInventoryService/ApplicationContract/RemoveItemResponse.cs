﻿namespace ShopBridge.Inventory.ApplicationContract
{
    public class RemoveItemResponse: InventoryServiceResponse
    {
    }
}
