﻿namespace ShopBridge.Inventory.ApplicationContract
{
    public class AddItemResponse: InventoryServiceResponse
    {
        public int AddedItemId { get; set; }
    }
}
