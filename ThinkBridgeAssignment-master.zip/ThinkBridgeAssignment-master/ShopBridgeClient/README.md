# ShopBridge
A basic app in Angular performing all the CRUD operations
