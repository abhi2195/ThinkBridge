export class Item {
    name: string;
    id: string;
    description: string;
    price: string;
}
